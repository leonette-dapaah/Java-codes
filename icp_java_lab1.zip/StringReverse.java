import java.util.Scanner;
import java.util.Calendar;

/*
 * This program reverses string input. 
 */
    public class StringReverse{
        public static String reverse(String a){
            if (a.isEmpty()){
                return a;
            }
            //Calling Function Recursively
            else{
                return reverse(a.substring(1)) + a.charAt(0);
            }
        }
        public static void reverseString(String words){
            String results = reverse(words);
            String[] newString = results.split(" ");
            String results2 = "";
            for(int i = newString.length -1; i > -1; i --){
                results2 += newString[i] + " ";

            }
            System.out.println(results2);
        }

        public static void main(String[] args){
            // create two long variables: startTime, endTime
            long startTime;
            long endTime;

            Scanner input = new Scanner(System.in);
            System.out.print("Enter a word or sentence: ");
            String str = input.nextLine();

            // set startTime to an instance of the Calendar class
            // Calendar.getInstance().getTimeInMillis()
            startTime = Calendar.getInstance().getTimeInMillis();

            reverseString(str);

            // set endTime to an instance of the Calendar class
            endTime = Calendar.getInstance().getTimeInMillis();

            // get the difference (which is a double variable)
            double d = endTime - startTime;
            System.out.println(d + " milliseconds.");
        }
    }
