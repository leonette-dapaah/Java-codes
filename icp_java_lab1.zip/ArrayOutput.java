public class ArrayOutput {
    public static void main(String args[]){
        int array_variable [] = new int[10]; //Note how the array is created (size)
        for (int i = 0; i < 10; ++i){
            /**
             * A try-catch method is used and throws an array index out
             * of bounds if the index exceeds that of the array size specified.
             */
            try{
                array_variable[i] = i;
                System.out.print(array_variable[i] + " ");
                i++;
            }
            catch (ArrayIndexOutOfBoundsException e){
                System.out.println("Array index out of bounds");
            }
        }
    }
}
