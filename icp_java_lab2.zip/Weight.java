
import java.util.Scanner;
import java.util.InputMismatchException;

/* This program evaluates a person's weight
 * based on a given criteria.
 */
public class Weight {
    public static void main(String[] agrs){
        float weight;
        
        System.out.println("Enter your weght: ");
        Scanner scan = new Scanner(System.in);
        
        /**
         * try-catch method to allow for graceful 
         * exception handling
         */
        try{
            weight = scan.nextFloat();
            if(weight <= 115)
              System.out.println("Eat 5 banana splits!");
        
            else if(weight <= 130)
              System.out.println("Eat a banana split!");
        
            else if(weight <=200)
              System.out.println("Perfect!");
        
            else
              System.out.println("Plenty of banana splits have been consumed!");
        }
        catch (InputMismatchException e){
          System.out.println("Invalid Input.");
        }
    }
}
