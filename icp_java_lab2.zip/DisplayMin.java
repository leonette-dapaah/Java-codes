
import java.util.Scanner;
import java.util.InputMismatchException;

 /* This prgram prompts a user for a series of numbers
  * and determines the smallest value entered.
  */
public class DisplayMin {
    public static void main(String[] args) {
        System.out.println("This program displays the smallest number per your input. " +
                "It takes in only integers");
        System.out.println("Enter 5 numbers: ");
        
        /**
         * try-catch method for exception handling
         * @InputMismatchException handles wrong inputs
         */
        
        try {
            Scanner s = new Scanner(System.in);
            int temp = Integer.MAX_VALUE;
            for (int i = 0; i < 5; i++) {
         // This method reads the number provided using the keyboard
                int u_input = s.nextInt();
                if (u_input < temp) {
                    temp = u_input;
                }
            }
            s.close();
            System.out.println("The smallest value is " + temp);
        }
        catch(InputMismatchException e){
            System.out.println("Invalid input.");
        }
    }
}