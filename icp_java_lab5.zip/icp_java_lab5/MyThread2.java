import java.lang.Runnable;
import java.lang.Thread;

/*
 * This program modifies the the first Thread program.
 * Here, we intend creating two threads; one printing "hello"
 * and the other, "goodbye".
 */
public class MyThread2 implements Runnable {
  private String text;  
  public static int i;
    
    public MyThread2 (String text){
      this.text = text;
    }

    public void run() {
        for (int i = 0; i < 5; i++) {
            System.out.println(Thread.currentThread().getName() + " : " + text);
            try {
                Thread.sleep(100);
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    
    public static void main (String[] args){
      // creating "hello" and "goodbye" threads  
      Runnable r = new MyThread2("hello");
        Thread t = new Thread(r);

        Runnable ru = new MyThread2("goodbye");
        Thread th = new Thread(ru);

        // starting threads
        t.start();
        th.start();
    }
}