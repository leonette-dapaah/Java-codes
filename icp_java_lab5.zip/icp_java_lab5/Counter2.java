import java.lang.Runnable;
import java.lang.Thread;

/* Modification of Counter class.
 * Maximum and minimum values of count are saved
 * within the Counter2 object.
 */
public class Counter2 {
    private int count;
    public int max;
    public int min;
    
    // constructor to initialize instance variables
    public Counter2() {
        count = 0;
        max = 0;
        min = 0;
    }

    public void increment() {

       count++;
       if(max < count)
         max = count;
    }

    public void decrement() {

        count--;
        if(min > count)
          min = count;
    }

    /*
     * @return count
     */
    public int getCount() {
        return count;
    }
    
    public static class decInc implements Runnable{
      private boolean type;
      private Counter2 c;
      
      public decInc(Counter2 c,boolean type){
        this.type = type;
        this.c = c;
      }
      
      @Override
      public void run(){
        if(type){
            for(int i = 0; i < 1000; i++) 
                c.increment();
          System.out.println("Counter Increment now:  " + c.getCount());
          System.out.println("The maximum value: " + c.max);
            
        }
        else if(!type){
          for(int i = 0; i < 1000; i++) 
                c.decrement();
          System.out.println("Counter decrement now:  " + c.getCount());
          System.out.println("The minimum value: " + c.min);  
        }
     } 
    }
    public static void main(String[] args) {
        Counter2 k = new Counter2();

        // creating the threads
        Runnable r = new decInc(k,true);
        Thread t = new Thread(r);

        Runnable ru = new decInc(k,false);
        Thread th = new Thread(ru);

        // starting threads
        t.start();
        th.start();

        System.out.println(k.getCount());
        try {
            Thread.sleep(100);
        }
        catch (Exception e) {
        }
    }
}