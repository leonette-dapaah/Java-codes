import java.lang.Runnable;
import java.lang.Thread;

/*
 * This program creates a thread to print out the message "hello" 
 * done in a finite counting loop.
 * After the tread creation, the main program prints out "goodbye"
 * then terminates.
 */
public class MyThread implements Runnable {
    public static int i;
    
    public void run(){
        for(int i = 0; i<5; i++) {
            System.out.println("hello");
            // Use of a try-catch block to handle exceptions
            try {
                Thread.sleep(100);
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("goodbye");
    }
    // main method to create the thread intended
    public static void main (String args[]){
        Runnable r = new MyThread();
        Thread t = new Thread(r);
        t.start();
    }
}
