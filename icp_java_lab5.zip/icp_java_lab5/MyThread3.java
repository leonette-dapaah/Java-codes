import java.lang.Runnable;
import java.lang.Thread;

/*
 * Further modification of the Thread class created.
 * This program seeks to number each threads output starting from one.
 */
public class MyThread3 implements Runnable {
  private String text;  
  public static int i;
  
  public MyThread3 (String text){
    this.text = text;
  }

    @Override
    public void run() {
      // creating a finite loop for the threads
        for (int i = 1; i <= 5; i++) {
            System.out.println(Thread.currentThread().getName() + " " + + i + " : " + text);
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    
    public static void main (String[] args){
      // creating "hello" and "goodbye" threads  
      Runnable r = new MyThread3("hello");
      Thread t = new Thread(r);

      Runnable ru = new MyThread3("goodbye");
      Thread th = new Thread(ru);
      
      //t.setPriority(1);

      // setting hello thread name and staring it
      t.setName("hello thread ");
      t.start();

      // try-catch block to handle possible exception
      try{
        /* join() method to ensure hello thread terminates execution
         * before goodbye thread is executed.
         */
        t.join();
      }
      catch (InterruptedException a){
        System.out.println ("Interrupted thread");
      }
      
      System.out.println();
      
      // setting goodbye thread name and starting it
      th.setName("goodbye thread ");
      th.start();
    }
}