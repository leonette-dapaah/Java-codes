import java.lang.Runnable;
import java.lang.Thread;
import java.lang.NullPointerException;

/* This program declares a shared counter
 * and creates two threads; each performing tasks.
 */
public class Counter {
    private int count;
    
    public Counter() {
        count = 0;
    }
    // increment method to increase count by 1
    public void increment() {
       count++;
    }
    // decrement method to decrease count by 1
    public void decrement() {
        count--;
    }
    // getCount method to keep track of the value of count
    public int getCount() {
        return count;
    }
    
    public static class decInc implements Runnable{
      private boolean type;
      private Counter c;
      
      public decInc(Counter c, boolean type){
        this.type = type;
        this.c = c;
      }
      
      @Override
      public void run(){
        if(type){
          // for loop to increase count 1000 times if true
            for(int i = 0; i < 1000; i++) 
                c.increment();
            System.out.println(c.getCount());
            
        }
        else if(!type){
          // for loop to decrease count 1000 times if false
          for(int i = 0; i < 1000; i++) 
                c.decrement();
          System.out.println(c.getCount());
        }
      }
      
    }
    public static void main(String[] args) {
        Counter k = new Counter();

        // creating the two threads
        Runnable r = new decInc(k, true);
        Thread t = new Thread(r);

        Runnable ru = new decInc(k, false);
        Thread th = new Thread(ru);

        // starting the threads
        t.start();
        th.start();

        // printing out the final value of count
        System.out.println(k.getCount());
        try {
            Thread.sleep(100);
        } 
        catch (Exception e) {
        }
    }
}